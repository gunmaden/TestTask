# Scenario: `Get Filtered Users Scenario`

- Duration time: `00:01:00`
- RPS: `70`
- Concurrent Copies: `100`

| __step__                 | __details__                                              |
|--------------------------|----------------------------------------------------------|
| name                     | `Get filtered Users`                                     |
| request count            | all = `4260`, OK = `4258`, failed = `2`                  |
| response time            | RPS = `70`, min = `283`, mean = `1396`, max = `4204`     |
| response time percentile | 50% = `1323`, 75% = `1621`, 95% = `2223`, StdDev = `437` |
| data transfer            | min = - , mean = - , max = - , all = -                   |
# Scenario: `Create User Scenario`

- Duration time: `00:01:00`
- RPS: `83`
- Concurrent Copies: `100`

| __step__                 | __details__                                              |
|--------------------------|----------------------------------------------------------|
| name                     | `Create user`                                            |
| request count            | all = `5033`, OK = `5025`, failed = `8`                  |
| response time            | RPS = `83`, min = `163`, mean = `1185`, max = `2736`     |
| response time percentile | 50% = `1154`, 75% = `1341`, 95% = `1730`, StdDev = `299` |
| data transfer            | min = - , mean = - , max = - , all = -                   |